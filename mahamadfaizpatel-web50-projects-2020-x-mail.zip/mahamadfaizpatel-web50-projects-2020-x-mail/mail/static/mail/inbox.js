document.addEventListener("DOMContentLoaded", function () {
  // Use buttons to toggle between views
  document
    .querySelector("#inbox")
    .addEventListener("click", () => load_mailbox("inbox"));
  document
    .querySelector("#sent")
    .addEventListener("click", () => load_mailbox("sent"));
  document
    .querySelector("#archived")
    .addEventListener("click", () => load_mailbox("archive"));
  document.querySelector("#compose").addEventListener("click", compose_email);

  // send mail on submit
  document.querySelector("#compose-form").addEventListener("submit", () => {
    sendMail(event);
  });

  // By default, load the inbox
  load_mailbox("inbox");
});

function display({ emails = "none", compose = "none", email = "none" }) {
  function restartAnimation(element) {
    const animation = element.style.animation;
    element.style.animation = "none";
    element.offsetHeight;
    element.style.animation = animation;
  }

  // access views
  const emailsView = document.querySelector("#emails-view");
  const composeView = document.querySelector("#compose-view");
  const emailView = document.querySelector("#email-view");

  // set default views to paused
  composeView.style.animationPlayState = "paused";
  emailsView.style.animationPlayState = "paused";
  emailView.style.animationPlayState = "paused";

  if (email === "block") {
    emailView.style.animationPlayState = "running";
  } else if (compose === "block") {
    restartAnimation(composeView);
    composeView.style.animationPlayState = "running";
  } else if (emails === "block") {
    restartAnimation(emailsView);
    emailsView.style.animationPlayState = "running";
  }

  // Show and hide  views
  composeView.style.display = compose;
  emailsView.style.display = emails;
  emailView.style.display = email;

  return null;
}

function compose_email() {
  // Show compose view and hide other views
  display({ compose: "block" });

  document.querySelector("#compose-header").innerHTML = "New Email";

  // Clear out composition fields
  document.querySelector("#compose-recipients").value = "";
  document.querySelector("#compose-subject").value = "";
  document.querySelector("#compose-body").value = "";
}

function load_mailbox(mailbox) {
  // Show the mailbox and hide other views
  display({ emails: "block" });

  // Show the mailbox name
  document.querySelector("#mailbox-name").innerHTML = `<h3>${
    mailbox.charAt(0).toUpperCase() + mailbox.slice(1)
  }</h3>`;

  // clear emails list
  const emailsList = document.querySelector("#emails-list");
  emailsList.innerHTML = "";

  // fetch the mails
  fetch(`/emails/${mailbox}`)
    .then((response) => response.json())
    .then((data) => {
      // for individual emails
      data.forEach((email, index) => {
        // for sender mailbox
        var person = "";
        if (mailbox === "sent") {
          person = email.recipients;
        } else {
          person = email.sender;
        }

        // individual email container
        const emailDiv = document.createElement("div");
        emailDiv.innerHTML = `<span class="person col-lg-2 col-md-3 col-sm-4">${person}</span> <span class="subject col-lg-8 col-md-6 col-sm-4">${email.subject}</span> <span class="timestamp col-lg-2 col-md-3 col-sm-4">${email.timestamp}</span>`;

        emailDiv.className = "row row-cols-3";

        // click event to view email
        emailDiv.addEventListener("click", () => {
          load_mail(email.id);
        });

        div = document.createElement("div");
        div.className = "list-group-item ";
        // change background color for read and unread
        div.className += email.read ? "bg-light" : "white";
        div.append(emailDiv);

        // loading animation
        console.log(index);
        div.style.animationDelay = `${100 * index + 1}ms`;
        div.style.animationPlayState = "running";
        // append each email to list
        emailsList.append(div);
      });

      // no emails in the list
      if (emailsList.children.length === 0) {
        const noEmail = document.createElement("div");
        noEmail.innerHTML = "No Emails!";
        noEmail.className = "alert alert-info";
        emailsList.append(noEmail);
      }
    });
}

function sendMail(event) {
  // stop reloading of page
  event.preventDefault();

  // get form value
  var recipients = document.querySelector("#compose-recipients").value;
  var subject = document.querySelector("#compose-subject").value;
  var body = document.querySelector("#compose-body").value;

  // post mail
  fetch("/emails", {
    method: "POST",
    body: JSON.stringify({
      recipients: recipients,
      subject: subject,
      body: body,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      // log response
      console.log(data);
      // redirect sent mailbox
      load_mailbox("sent");
    });
}

function load_mail(id) {
  // Show the email view and hide other views
  display({ email: "block" });

  fetch(`/emails/${id}`)
    .then((response) => response.json())
    .then((data) => {
      // Email Name i.e subject
      document.querySelector(
        "#email-name"
      ).innerHTML = `<h3>${data.subject}</h3>`;

      // capitalise name
      document.querySelector("#email-name").style.textTransform = "capitalize";

      // archive button
      document.querySelector("#archived-btn").innerHTML = data.archived
        ? "Unarchive"
        : "Archive";

      // email detail
      document.querySelector("#email-detail").innerHTML = `
      <li class="list-group-item"><span>Sender:</span>${data.sender}</li>
      <li class="list-group-item"><span>Recipients:</span>${data.recipients}</li>
      <li class="list-group-item"><span>Subject:</span>${data.subject}</li>
      <li class="list-group-item"><span>Timestamp:</span>${data.timestamp}</li>`;

      // email body
      document.querySelector("#email-body").innerHTML = data.body;

      // mark as read
      if (data.read === false) {
        fetch(`/emails/${data.id}`, {
          method: "PUT",
          body: JSON.stringify({
            read: true,
          }),
        });
      }

      // Archive button action
      document.querySelector("#archived-btn").addEventListener("click", () => {
        archiveMail(data);
      });

      // Reply button action
      document.querySelector("#reply-btn").addEventListener("click", () => {
        replyMail(data);
      });
    });
}

function archiveMail(data) {
  fetch(`/emails/${data.id}`, {
    method: "PUT",
    body: JSON.stringify({
      archived: !data.archived,
    }),
  }).then((response) => {
    setTimeout(() => {
      load_mailbox("inbox");
    }, 200);
  });
}

function replyMail(email) {
  // Show compose view and hide other views
  display({ compose: "block" });

  document.querySelector("#compose-header").innerHTML = "Reply Email";

  var sender = email.sender;
  var subject = email.subject;
  var body = `On ${email.timestamp} ${email.sender} wrote:\n${email.body}\n---\n`;

  // prefill composition fields
  document.querySelector("#compose-recipients").value = sender;
  document.querySelector("#compose-subject").value = subject.startsWith("Re:")
    ? subject
    : "Re: " + subject;
  document.querySelector("#compose-body").value = body;
}
